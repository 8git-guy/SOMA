#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/hayashi/soma_ws/devel/.private/maxon_epos_msgs:$CMAKE_PREFIX_PATH"
export PWD='/home/hayashi/soma_ws/build/maxon_epos_msgs'
export ROSLISP_PACKAGE_DIRECTORIES="/home/hayashi/soma_ws/devel/.private/maxon_epos_msgs/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/hayashi/soma_ws/src/maxon_epos_ros/maxon_epos_msgs:$ROS_PACKAGE_PATH"