# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/hayashi/soma_ws/src/maxon_epos_ros/maxon_epos_msgs/msg/MotorState.msg;/home/hayashi/soma_ws/src/maxon_epos_ros/maxon_epos_msgs/msg/MotorStates.msg"
services_str = ""
pkg_name = "maxon_epos_msgs"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "maxon_epos_msgs;/home/hayashi/soma_ws/src/maxon_epos_ros/maxon_epos_msgs/msg;std_msgs;/opt/ros/noetic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python3"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/noetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
