# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/hayashi/soma_ws/src/soma_pkg/soma_msgs/msg/SOMAStatus.msg"
services_str = "/home/hayashi/soma_ws/src/soma_pkg/soma_msgs/srv/GetGraphBasedPlan.srv"
pkg_name = "soma_msgs"
dependencies_str = "std_msgs;nav_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "soma_msgs;/home/hayashi/soma_ws/src/soma_pkg/soma_msgs/msg;std_msgs;/opt/ros/noetic/share/std_msgs/cmake/../msg;nav_msgs;/opt/ros/noetic/share/nav_msgs/cmake/../msg;geometry_msgs;/opt/ros/noetic/share/geometry_msgs/cmake/../msg;actionlib_msgs;/opt/ros/noetic/share/actionlib_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python3"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/noetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
